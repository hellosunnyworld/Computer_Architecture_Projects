//
// Created by 林沐晗 on 2021/3/19.
//

#include "assembler.h"
#include "memory.h"
#include <cmath>
#include <exception>
#include <bitset>
#include <iostream>
using namespace std;

set<string> RdRsRt = {"add", "addu", "and", "nor", "or", "sub", "subu", "xor", "slt", "sltu"};
set<string> RdRtRs = {"sllv", "srav", "srlv"};
set<string> RsRt = {"div", "divu", "mult", "multu", "madd", "maddu", "msub", "msubu", "teq", "tne", "tge", "tgeu", "tlt", "tltu"};
set<string> RsRd = {"jalr"};
set<string> Rs = {"jr", "mthi", "mtlo"};
set<string> Rd = {"mfhi", "mflo"};
set<string> RdRtSh = {"sll", "sra", "srl"};
set<string> RtRsImm = {"addi", "addiu", "andi", "ori", "xori", "slti", "sltiu"};
set<string> RtImm = {"lui"};
set<string> RsImm = {"teqi", "tnei", "tgei", "tgeiu", "tlt", "tltiu"};
set<string> RsRtOff = {"beq", "bne"};
set<string> RtOffRs = {"lw", "sw", "lb", "lbu", "lh", "lhu", "lwl", "lwr", "ll", "sc", "sb", "sh", "swl", "swr"};
set<string> RsOff = {"bgez", "bgezal", "bgtz", "blez", "bltzal", "bltz"};
set<string> jCode = {"j", "jal"};

void InstruMapInit(std::map<std::string,std::vector<int>>& InstruMap){
    InstruMap["add"] = {0, 0x20};
    InstruMap["addu"] = {0, 0x21};
    InstruMap["addi"] = {8};
    InstruMap["addiu"] = {9};
    InstruMap["and"] = {0, 0x24};
    InstruMap["andi"] = {0xc};
    InstruMap["clo"] = {0x1c, 0x21};
    InstruMap["clz"] = {0x1c, 0x20};
    InstruMap["div"] = {0, 0x1a};
    InstruMap["divu"] = {0, 0x1b};
    InstruMap["mult"] = {0, 0x18};
    InstruMap["multu"] = {0, 0x19};
    InstruMap["mul"] = {0x1c, 2};
    InstruMap["madd"] = {0x1c, 0};
    InstruMap["maddu"] = {0x1c, 1};
    InstruMap["msub"] = {0x1c, 4};
    InstruMap["msubu"] = {0x1c, 5};
    InstruMap["nor"] = {0, 0x27};
    InstruMap["or"] = {0, 0x25};
    InstruMap["ori"] = {0xd};
    InstruMap["sll"] = {0, 0};
    InstruMap["sllv"] = {0, 4};
    InstruMap["sra"] = {0, 3};
    InstruMap["srav"] = {0, 7};
    InstruMap["srl"] = {0, 2};
    InstruMap["srlv"] = {0, 6};
    InstruMap["sub"] = {0, 0x22};
    InstruMap["subu"] = {0, 0x23};
    InstruMap["xor"] = {0, 0x26};
    InstruMap["xori"] = {0xe};
    InstruMap["lui"] = {0xf};
    InstruMap["slt"] = {0, 0x2a};
    InstruMap["sltu"] = {0, 0x2b};
    InstruMap["slti"] = {0xa};
    InstruMap["sltiu"] = {0xb};
    InstruMap["beq"] = {4};
    InstruMap["bgez"] = {1, 1};
    InstruMap["bgezal"] = {1, 0x11};
    InstruMap["bgtz"] = {7, 0};
    InstruMap["blez"] = {6, 0};
    InstruMap["bltzal"] = {1, 0x10};
    InstruMap["bltz"] = {1, 0};
    InstruMap["bne"] = {5};
    InstruMap["j"] = {2};
    InstruMap["jal"] = {3};
    InstruMap["jalr"] = {0, 9};
    InstruMap["jr"] = {0, 8};
    InstruMap["teq"] = {0, 0x34};
    InstruMap["teqi"] = {1, 0xc};
    InstruMap["tne"] = {0, 0x36};
    InstruMap["tnei"] = {1, 0xe};
    InstruMap["tge"] = {0, 0x30};
    InstruMap["tgeu"] = {0, 0x31};
    InstruMap["tgei"] = {1, 8};
    InstruMap["tgeiu"] = {1, 9};
    InstruMap["tlt"] = {0, 0x32};
    InstruMap["tltu"] = {0, 0x33};
    InstruMap["tlti"] = {1, 0xa};
    InstruMap["tltiu"] = {1, 0xb};
    InstruMap["lb"] = {0x20};
    InstruMap["lbu"] = {0x24};
    InstruMap["lh"] = {0x21};
    InstruMap["lhu"] = {0x25};
    InstruMap["lw"] = {0x23};
    InstruMap["lwl"] = {0x22};
    InstruMap["lwr"] = {0x26};
    InstruMap["ll"] = {0x30};
    InstruMap["sb"] = {0x28};
    InstruMap["sh"] = {0x29};
    InstruMap["sw"] = {0x2b};
    InstruMap["swl"] = {0x2a};
    InstruMap["swr"] = {0x2e};
    InstruMap["sc"] = {0x38};
    InstruMap["mfhi"] = {0, 0x10};
    InstruMap["mflo"] = {0, 0x12};
    InstruMap["mthi"] = {0, 0x11};
    InstruMap["mtlo"] = {0, 0x13};
}
void rAssemble(int op, int rs, int rt, int rd, int shamt, int funct){
    *crtText = (op << 5) + rs;
    *crtText = (*crtText << 5) + rt;
    *crtText = (*crtText << 5) + rd;
    *crtText = (*crtText << 5) + shamt;
    *crtText = (*crtText << 6) + funct;
}
void iAssemble(int op, int rs, int rt, int ac) {
    *crtText = (op << 5) + rs;
    *crtText = (*crtText << 5) + rt;
    *crtText = (*crtText << 16) + (ac & 65535);
}
void jAssemble(int op, int ad){
    unsigned int crtPos = pseudo_mem(memory, crtText);
    unsigned int highDigits = (crtPos >> 28) << 28;
    unsigned int off = (ad - highDigits) / 4;
    *crtText = (op << 26) + off;
}

void assemble(std::vector<std::string>& text, std::map<std::string, int>& RegisterMap, std::map<std::string,std::vector<int>>& InstruMap, map<string, int*>& SymbolTable){
    string opt = text[0];
    if (opt == "syscall")   *crtText = 0b00000000000000000000000000001100;

    else if (RdRsRt.find(opt) != RdRsRt.end())
        rAssemble(InstruMap[opt][0], RegisterMap[text[2]], RegisterMap[text[3]], RegisterMap[text[1]], 0, InstruMap[opt][1]);

    else if (RdRtRs.find(opt) != RdRtRs.end())
        rAssemble(InstruMap[opt][0], RegisterMap[text[3]], RegisterMap[text[2]], RegisterMap[text[1]], 0, InstruMap[opt][1]);

    else if (RsRt.find(opt) != RsRt.end())
        rAssemble(InstruMap[opt][0], RegisterMap[text[1]], RegisterMap[text[2]], 0, 0, InstruMap[opt][1]);

    else if (RsRd.find(opt) != RsRd.end())
        rAssemble(InstruMap[opt][0], RegisterMap[text[2]], 0, RegisterMap[text[1]], 0, InstruMap[opt][1]);

    else if (Rs.find(opt) != Rs.end())
        rAssemble(InstruMap[opt][0], RegisterMap[text[1]], 0, 0, 0, InstruMap[opt][1]);

    else if (Rd.find(opt) != Rd.end())
        rAssemble(InstruMap[opt][0], 0, 0, RegisterMap[text[1]], 0, InstruMap[opt][1]);

    else if (RdRtSh.find(opt) != RdRtSh.end())
        rAssemble(InstruMap[opt][0], 0, RegisterMap[text[2]], RegisterMap[text[1]], stoi(text[3],nullptr,0), InstruMap[opt][1]);

    else if (RtRsImm.find(opt) != RtRsImm.end())
        iAssemble(InstruMap[opt][0], RegisterMap[text[2]], RegisterMap[text[1]], stoi(text[3],nullptr,0));

    else if (RtImm.find(opt) != RtImm.end())
        iAssemble(InstruMap[opt][0], 0, RegisterMap[text[1]], stoi(text[2],nullptr,0));

    else if (RsImm.find(opt) != RsImm.end())
        iAssemble(InstruMap[opt][0], RegisterMap[text[1]], InstruMap[opt][1], stoi(text[2],nullptr,0));

    else if (RsRtOff.find(opt) != RsRtOff.end()){
        string label = text[text.size() - 1];
        try{
            iAssemble(InstruMap[opt][0], RegisterMap[text[1]], RegisterMap[text[2]], stoi(text[3],nullptr,0));
        }catch (std::invalid_argument& e) {
            iAssemble(InstruMap[opt][0], RegisterMap[text[1]], RegisterMap[text[2]], SymbolTable[label] - crtText - 1);
        }
    }

    else if (RtOffRs.find(opt) != RtOffRs.end())
        iAssemble(InstruMap[opt][0], RegisterMap[text[3]], RegisterMap[text[1]], stoi(text[2],nullptr,0));

    else if (RsOff.find(opt) != RsOff.end()){
        string label = text[text.size() - 1];
        try{
            iAssemble(InstruMap[opt][0], RegisterMap[text[1]], InstruMap[opt][1], stoi(text[2],nullptr,0));
        }catch (std::invalid_argument& e) {
            iAssemble(InstruMap[opt][0], RegisterMap[text[1]], InstruMap[opt][1], SymbolTable[label] - crtText - 1);
        }
    }

    else if (jCode.find(opt) != jCode.end()){
        try{
            jAssemble(InstruMap[opt][0], stoi(text[1]));
        } catch (std::invalid_argument& e) {
            jAssemble(InstruMap[opt][0], pseudo_mem(*pc, SymbolTable[text[1]]));
        }
    }

    crtText += 1;
}