//
// Created by 林沐晗 on 2021/3/19.
//

#ifndef PROJECTFSTR_ASSEMBLER_H
#define PROJECTFSTR_ASSEMBLER_H
#include <map>
#include <string>
#include <vector>
#include <set>

extern std::set<std::string> RdRtRs;
extern std::set<std::string> RdRsRt;
extern std::set<std::string> RsRt;
extern std::set<std::string> RsRd;
extern std::set<std::string> Rs;
extern std::set<std::string> Rd;
extern std::set<std::string> RdRtSh;
extern std::set<std::string> RtRsImm;
extern std::set<std::string> RtImm;
extern std::set<std::string> RsImm;
extern std::set<std::string> RsRtOff;
extern std::set<std::string> RsOff;
extern std::set<std::string> jCode;

void InstruMapInit(std::map<std::string,std::vector<int>>& InstruMap);
void rAssemble(int op, int rs, int rt, int rd, int shamt, int funct);
void iAssemble(int op, int rs, int rt, int ac);
void jAssemble(int op, int ad);
void assemble(std::vector<std::string>& text, std::map<std::string, int>& RegisterMap, std::map<std::string,std::vector<int>>& InstruMap, std::map<std::string, int*>& SymbolTable);

#endif //PROJECTFSTR_ASSEMBLER_H
