//
// Created by 林沐晗 on 2021/3/19.
//

#include "data.h"
#include "memory.h"
#include <iostream>
using namespace std;

void ascii (string& str){
    int num = 0;
    bool escape = 0;
    //str = str.substr(1,str.length() - 2); // Removes ""
    for (int i = 0; i < int(str.length()); i += 4){ // <= is to record \0
        for (int j = 0; j < 4; j++){
            if ((i + j) > str.length())    break;
            else if ((str[i + j] != '\\') || (escape)){
                num = num  + ((str[i + j]) << (8 * (i + j)));
                escape = 0;
            }
            else{
                if (str[i + j + 1] == '\\')
                    escape = 1;//escape sign
                else if (str[i + j + 1] == 'n'){
                    num = num  + (10 << (8 * (i + j)));
                    j++;
                }
                else if (str[i + j + 1] == 't'){
                    num = num  + (9 << (8 * (i + j)));
                    j++;
                }
                else if (str[i + j + 1] == '0'){
                    num = num  + (0 << (8 * (i + j)));
                    j++;
                }
            }
        }
        *crtStatic = num;
        crtStatic += 1;
        num = 0;
    }
}

void asciiz (string& str){
    int num = 0;
    bool escape = 0;
    //str = str.substr(1,str.length() - 2); // Removes ""
    for (int i = 0; i <= int(str.length()); i += 4){ // <= is to record \0
        for (int j = 0; j < 4; j++){
            if ((i + j) > str.length())    break;
            else if ((str[i + j] != '\\') || (escape)){
                num = num  + ((str[i + j]) << (8 * (i + j)));
                escape = 0;
            }
            else{
                if (str[i + j + 1] == '\\')
                    escape = 1;//escape sign
                else if (str[i + j + 1] == 'n'){
                    num = num  + (10 << (8 * (i + j)));
                    j++;
                }
                else if (str[i + j + 1] == 't'){
                    num = num  + (9 << (8 * (i + j)));
                    j++;
                }
                else if (str[i + j + 1] == '0'){
                    num = num  + (0 << (8 * (i + j)));
                    j++;
                }
            }
        }
        *crtStatic = num;
        crtStatic += 1;
        num = 0;
    }
}

void byte (vector<string>& vec){
    int a, b, c, d;
    for (int i = 2; i < int(vec.size()); i += 4){
        a = atoi(vec[i].c_str());
        b = atoi(vec[i + 1].c_str()) << 8;
        c = atoi(vec[i + 2].c_str()) << 16;
        d = atoi(vec[i + 3].c_str()) << 24;
        *crtStatic = a + b + c + d;
        crtStatic += 1;
    } // Discards var name and .byte
}

void half (vector<string>& vec){
    for (int i = 2; i < int(vec.size()); i += 2){
        *crtStatic = atoi(vec[i].c_str()) + (atoi(vec[i + 1].c_str()) << 16);
        crtStatic += 1;
    } // Discards var name and .byte
}

void word (vector<string>& vec){
    for (int i = 2; i < int(vec.size()); i++){
        *crtStatic = atoi(vec[i].c_str());
        crtStatic += 1;
    } // Discards var name and .byte
}



void storeData (vector<string>& data, map<string, int*> st){
    st[data[0]] = crtStatic;
    //std::cout<<"hello"<<std::endl;
    if (data[1] == ".ascii")    ascii(data[2]);
    else if (data[1] == ".asciiz")  asciiz(data[2]);
    else if (data[1] == ".byte")    byte(data);
    else if (data[1] == ".half")    half(data);
    else if (data[1] == ".word")    word(data);
}