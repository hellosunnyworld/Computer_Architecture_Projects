//
// Created by 林沐晗 on 2021/3/19.
//

#ifndef PROJECTFSTR_DATA_H
#define PROJECTFSTR_DATA_H
#include <string>
#include <vector>
#include <map>

void ascii (std::string& str);
void asciiz (std::string& str);
void byte (std::vector<std::string>& vec);
void half (std::vector<std::string>& vec);
void word (std::vector<std::string>& vec);

void storeData (std::vector<std::string>& data, std::map<std::string, int*> st);

#endif //PROJECTFSTR_DATA_H
