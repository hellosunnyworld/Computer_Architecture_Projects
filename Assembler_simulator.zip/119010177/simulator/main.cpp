#include <cstdio>
#include <cstdlib>
#include "memory.h"
#include "supports.h"
#include "data.h"
#include "assembler.h"
#include "simulator.h"
#include <vector>
#include <string>
#include <map>
#include <iostream>
#include <bitset>
#include <fstream>
using namespace std;

void getFile (vector<vector<string>>& data, vector<vector<string>>& texts, map<string, int*>& st, ifstream& input_mips);
bool RmComment (string& txt);
string ProcLabel (map<string, int*>& st, string& txt, int& state);
bool Tocken (string& txt, vector<vector<string>>& vec);

void getFile (vector<vector<string>>& data, vector<vector<string>>& texts, map<string, int*>& st, ifstream& input_mips){
    string txt;
    char t[1000];
    int state = 1;
    string label;
    int* crtCode = crtText;
    bool full;
    while (getline(input_mips, txt)){
        //txt = string(t);
        if (RmComment(txt)) {
            label = ProcLabel(st, txt, state);
            if (label != "") {
                vector<string> inst;
                if (state == 0) {
                    data.push_back(inst);
                    data[data.size() - 1].push_back(label);
                    full = Tocken(txt, data);
                    if (!full) data.pop_back();
                } else if (state == 1) {
                    texts.push_back(inst);
                    full = Tocken(txt, texts);
                    if (full) crtText += 1;
                    else texts.pop_back();
                }
            }
        }
    }
    crtText = crtCode;
}
//void getFile (vector<vector<string>>& data, vector<vector<string>>& texts, map<string, int*>& st){
//    string txt;
//    int state = 1;
//    string label;
//    int* crtCode = crtText;
//    bool full;
//    txt = "";
//    getline(cin, txt);
//    while (txt != "q"){
//        if (RmComment(txt)) {
//            label = ProcLabel(st, txt, state);
//            if (label != "") {
//                vector<string> inst;
//                if (state == 0) {
//                    data.push_back(inst);
//                    data[data.size() - 1].push_back(label);
//                    full = Tocken(txt, data);
//                    if (!full) data.pop_back();
//                } else if (state == 1) {
//                    texts.push_back(inst);
//                    full = Tocken(txt, texts);
//                    if (full) crtText += 1;
//                    else texts.pop_back();
//                }
//            }
//        }
//        getline(cin, txt);
//    }
//    crtText = crtCode;
//}

bool RmComment (string& txt){
    int pos = txt.find('#', 0);

    if (pos == 0)   return false; // Comment line
    else if (pos != string::npos)
        txt = txt.substr(0, pos);

    return true;
}
string ProcLabel (map<string, int*>& st, string& txt, int& state){
// Returns the label.
// If this line is .data or .text, returns "".
// Else if there is no labels, return " ".

    // Search for the segment
    int segmentPos1 = txt.find(".data", 0);
    if (segmentPos1 != string::npos){
        state = 0;

        int adhPos = txt.find('<') ;
        if (adhPos != string::npos){
            int adePos = txt.find('>') ;
            if (state == 0)
                *crtStatic = stoi(txt.substr(adhPos + 1, adePos - adhPos - 1));
            else if (state == 1)
                *crtText = stoi(txt.substr(adhPos + 1, adePos - adhPos - 1));
        }
        return "";
    }
    int segmentPos2 = txt.find(".text", 0);
    if (segmentPos2 != string::npos){
        state = 1;

        int adhPos = txt.find('<') ;
        if (adhPos != string::npos){
            int adePos = txt.find('>') ;
            if (state == 0)
                *crtStatic = stoi(txt.substr(adhPos + 1, adePos - adhPos - 1));
            else if (state == 1)
                *crtText = stoi(txt.substr(adhPos + 1, adePos - adhPos - 1));
        }
        return "";
    }
    // Search for a label
    int labelPos = txt.find(':', 0);
    if (labelPos != string::npos){
        int labelHead;
        for (int i = 0; i < labelPos; i++){
            labelHead = i;
            if (txt[i] != ' ')  break;
        }
        string label = txt.substr(labelHead, labelPos - labelHead);
        // Records in the symbol table
        if (state == 1)
            st[label] = crtText;
        txt = txt.substr(labelPos + 1);
        return label;
    }
    else    return " ";
}
bool Tocken (string& txt, vector<vector<string>>& vec){
    // Returns whether this line is empty
    bool record = 0;
    bool full = 0;
    int start;
    set<char> charIgnored = {',', ' ', '(', ')', '\t', '\n'};
    for (int i = 0; i < txt.length(); i++){
        if ((txt[i] == '"') && (txt[i - 1] != '\\')){
            int end = txt.find('"', i + 1);
            vec[vec.size() - 1].push_back(txt.substr(i + 1, end - i - 1));
            return true;
        }
        if ((charIgnored.find(txt[i]) == charIgnored.end()) && (!record)){
            record = 1;
            full = 1;
            start = i;
        }
        else if ((charIgnored.find(txt[i]) != charIgnored.end()) && (record)){
            record = 0;
            vec[vec.size() - 1].push_back(txt.substr(start, i - start));
        }
    }
    if (record == 1)    vec[vec.size() - 1].push_back(txt.substr(start, txt.length() - start));
    return full;
}

int main(int argc, char** argv) {
    if(argc < 4){
        printf("wrong number of arguments");
    }

    map<string, vector<int>> InstruMap;
    InstruMapInit(InstruMap);

    // Memory simulation
    memory = new int [1024 * 1024 * 6 / 4];
    crtText = real_mem(memory, TEXT);
    crtStatic = real_mem(memory, STATIC_DATA);
    crtStack = real_mem(memory, STACK);

    // Register simulation
    registers = new int [32];
    pc = new int*;
    lo = new int[2];
    hi = lo + 1;
    registersInit(memory);
    map<string, int> RegisterMap;
    RegMapInit(RegisterMap);

    // Deals with MIPS file entered
    vector<vector<string>> data;
    vector<vector<string>> texts;
    map<string, int*> SymbolTable;

    // input_mips = fopen(argv[1], "r");
    // syscall_inputs = fopen(argv[2], "r");
    // output_file = fopen(argv[3], "w");
    ifstream input_mips;
    ifstream syscall_inputs;
    ofstream output_file;

    input_mips.open(argv[1]);
    syscall_inputs.open(argv[2]);
    output_file.open(argv[3]);
    if (!output_file)   cout<<"fail!!"<<endl;
    // input_mips.open("fib.asm");
    // syscall_inputs.open("fib.in");
    // if (syscall_inputs.fail()) cout<<"fail!!!"<<endl;

    // char str[100];
    // syscall_inputs.read(str, 100);
    // cout << str << endl;
    //syscall_inputs.seekg(syscall_inputs.beg);
    
    // output_file.open("fib.out");
    getFile(data, texts, SymbolTable, input_mips);

    //cout<<"fibonacci "<<bitset<32>(SymbolTable["fibonacci"])<<endl;
    for (int i = 0; i < int(data.size()); i++){
        storeData(data[i], SymbolTable);
    }
    heapTop = crtStatic;
    //cout <<"jello again"<<endl;
    //cout<<texts.size()<<endl;
    for (int i = 0; i < int(texts.size()); i++){
        assemble(texts[i], RegisterMap, InstruMap, SymbolTable);
        //cout<<i<<endl;
    }

    //cout<<"opc "<<bitset<32>(*pc)<<endl;
    //cout<<"crtText "<<bitset<32>(crtText)<<endl;

    std::map<unsigned int, RType0*> R0FuncMap;
    std::map<unsigned int, RType0x1c*> R0x1cFuncMap;
    std::map<unsigned int, IType*> I1FuncMap;
    std::map<unsigned int, IType*> IFuncMap;
    std::map<unsigned int, JType*> JFuncMap;
    
    R0FuncMapInit(R0FuncMap);
    R0x1cFuncMapInit(R0x1cFuncMap);
    I1FuncMapInit(I1FuncMap);
    IFuncMapInit(IFuncMap);
    JFuncMapInit(JFuncMap);

    while (*pc != crtText){
        simulate(**pc, R0FuncMap, R0x1cFuncMap, I1FuncMap, IFuncMap, JFuncMap, syscall_inputs, output_file);
        *pc += 1;
    }
    // delete [] memory;
    // delete [] registers;
    // delete hi;
    // delete lo;
    // delete pc;
    input_mips.close();
    syscall_inputs.close();
    output_file.close();
    return 0;
}
