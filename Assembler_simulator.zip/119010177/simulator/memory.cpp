//
// Created by 林沐晗 on 2021/3/19.
//

#include "memory.h"
const int TEXT = 0x400000;
const int STATIC_DATA = 0x500000;
const int STACK = 0x400000 + 1024 * 1024 * 6 / 4;
int a = 0;
int* crtText = &a;
int* crtStatic = &a;
int* crtStack = &a;
int* heapTop = &a;

int *memory = &a;
int *registers = &a;
int **pc = &crtText;
int *hi = &a;
int *lo = &a;

int* real_mem(int* realRoot, int mem){
    return realRoot + (mem - 0x400000) / 4;
}
int pseudo_mem(int* realRoot, int* mem){
    return 0x400000 + (mem - realRoot) * 4;
}

void registersInit(int *memory){
    *registers = 0;
    for (int i = 2; i < 26; i++){
        *(registers + i) = 0;
    }
    *(registers + 28) = STATIC_DATA; //$gp
    *(registers + 29) = STACK; //$sp
    *(registers + 30) = STACK; //$fp
    *(registers + 31) = TEXT; //$ra
    *pc = real_mem(memory, TEXT);
    *hi = 0;
    *lo = 0;
}

void RegMapInit(std::map<std::string, int>& RegisterMap){
// Maps the registers' name to their index
    RegisterMap["$zero"] = 0;
    RegisterMap["$at"] = 1;
    RegisterMap["$v0"] = 2;
    RegisterMap["$v1"] = 3;
    RegisterMap["$a0"] = 4;
    RegisterMap["$a1"] = 5;
    RegisterMap["$a2"] = 6;
    RegisterMap["$a3"] = 7;
    RegisterMap["$t0"] = 8;
    RegisterMap["$t1"] = 9;
    RegisterMap["$t2"] = 10;
    RegisterMap["$t3"] = 11;
    RegisterMap["$t4"] = 12;
    RegisterMap["$t5"] = 13;
    RegisterMap["$t6"] = 14;
    RegisterMap["$t7"] = 15;
    RegisterMap["$s0"] = 16;
    RegisterMap["$s1"] = 17;
    RegisterMap["$s2"] = 18;
    RegisterMap["$s3"] = 19;
    RegisterMap["$s4"] = 20;
    RegisterMap["$s5"] = 21;
    RegisterMap["$s6"] = 22;
    RegisterMap["$s7"] = 23;
    RegisterMap["$t8"] = 24;
    RegisterMap["$t9"] = 25;
    RegisterMap["$k0"] = 26;
    RegisterMap["$k1"] = 27;
    RegisterMap["$gp"] = 28;
    RegisterMap["$sp"] = 29;
    RegisterMap["$fp"] = 30;
    RegisterMap["$ra"] = 31;
}