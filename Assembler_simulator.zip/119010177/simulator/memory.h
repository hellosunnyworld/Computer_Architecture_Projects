//
// Created by 林沐晗 on 2021/3/19.
//

#ifndef PROJECTFSTR_MEMORY_H
#define PROJECTFSTR_MEMORY_H
#include <map>
#include <string>
// Records the address of each component of memory
extern const int TEXT;
extern const int STATIC_DATA;
extern const int STACK;
// Points to current first free area
extern int* crtText;
extern int* crtStatic;
extern int* crtStack;
extern int* heapTop;

extern int* memory;
extern int *registers;
extern int** pc;
extern int *hi;
extern int *lo;


int* real_mem(int* realRoot, int mem);
int pseudo_mem(int* realRoot, int* mem);
void registersInit(int *memory);
void RegMapInit(std::map<std::string, int>& RegisterMap);
#endif //PROJECTFSTR_MEMORY_H
