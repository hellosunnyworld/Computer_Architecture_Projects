//
// Created by 林沐晗 on 2021/3/19.
//

#include "simulator.h"
#include "memory.h"
#include "supports.h"
#include <cmath>
void R0FuncMapInit(std::map<unsigned int, RType0*>& R0FuncMap){
    R0FuncMap[0x20] = add;
    R0FuncMap[0x21] = addu;
    R0FuncMap[0x24] = and_;
    R0FuncMap[0x1a] = div_;
    R0FuncMap[0x1b] = divu;
    R0FuncMap[0x18] = mult;
    R0FuncMap[0x19] = multu;
    R0FuncMap[0x27] = nor;
    R0FuncMap[0x25] = or_;
    R0FuncMap[0] = sll;
    R0FuncMap[4] = sllv;
    R0FuncMap[3] = sra;
    R0FuncMap[7] = srav;
    R0FuncMap[2] = srl;
    R0FuncMap[6] = srlv;
    R0FuncMap[0x22] = sub;
    R0FuncMap[0x23] = subu;
    R0FuncMap[0x26] = xor_;
    R0FuncMap[0x2a] = slt;
    R0FuncMap[0x2b] = sltu;
    R0FuncMap[9] = jalr;
    R0FuncMap[8] = jr;
    R0FuncMap[0x34] = teq;
    R0FuncMap[0x36] = tne;
    R0FuncMap[0x30] = tge;
    R0FuncMap[0x31] = tgeu;
    R0FuncMap[0x32] = tlt;
    R0FuncMap[0x33] = tltu;
    R0FuncMap[0x10] = mfhi;
    R0FuncMap[0x12] = mflo;
    R0FuncMap[0x11] = mthi;
    R0FuncMap[0x13] = mtlo;
}
void R0x1cFuncMapInit(std::map<unsigned int, RType0x1c*>& R0x1cFuncMap){
    R0x1cFuncMap[0x21] = clo;
    R0x1cFuncMap[0x20] = clz;
    R0x1cFuncMap[2] = mul;
    R0x1cFuncMap[0] = madd;
    R0x1cFuncMap[1] = maddu;
    R0x1cFuncMap[4] = msub;
    R0x1cFuncMap[5] = msubu;
}
void I1FuncMapInit(std::map<unsigned int, IType*>& I1FuncMap){
    I1FuncMap[1] = bgez;
    I1FuncMap[0x11] = bgezal;
    I1FuncMap[0x10] = bltzal;
    I1FuncMap[0] = bltz;
    I1FuncMap[0xc] = teqi;
    I1FuncMap[0xe] = tnei;
    I1FuncMap[8] = tgei;
    I1FuncMap[9] = tgeiu;
    I1FuncMap[0xa] = tlti;
    I1FuncMap[0xb] = tltiu;
}
void IFuncMapInit(std::map<unsigned int, IType*>& IFuncMap){
    IFuncMap[8] = addi;
    IFuncMap[9] = addiu;
    IFuncMap[0xc] = andi;
    IFuncMap[0xd] = ori;
    IFuncMap[0xe] = xori;
    IFuncMap[0xf] = lui;
    IFuncMap[0xa] = slti;
    IFuncMap[0xb] = sltiu;
    IFuncMap[4] = beq;
    IFuncMap[7] = bgtz;
    IFuncMap[6] = blez;
    IFuncMap[5] = bne;
    IFuncMap[0x20] = lb;
    IFuncMap[0x24] = lbu;
    IFuncMap[0x21] = lh;
    IFuncMap[0x25] = lhu;
    IFuncMap[0x23] = lw;
    IFuncMap[0x22] = lwl;
    IFuncMap[0x26] = lwr;
    IFuncMap[0x30] = ll;
    IFuncMap[0x28] = sb;
    IFuncMap[0x29] = sh;
    IFuncMap[0x2b] = sw;
    IFuncMap[0x2a] = swl;
    IFuncMap[0x2e] = swr;
    IFuncMap[0x38] = sc;
}
void JFuncMapInit(std::map<unsigned int, JType*>& JFuncMap){
    JFuncMap[2] = j;
    JFuncMap[3] = jal;
}

void simulate(unsigned int bCode, std::map<unsigned int, RType0*>& R0FuncMap,
              std::map<unsigned int, RType0x1c*>& R0x1cFuncMap,
              std::map<unsigned int, IType*>& I1FuncMap,
              std::map<unsigned int, IType*>& IFuncMap,
              std::map<unsigned int, JType*>& JFuncMap,
              std::ifstream& syscall_inputs, std::ofstream& output_file){

    if (bCode == 0b00000000000000000000000000001100){
        syscall(syscall_inputs, output_file);
    }
    else{
        unsigned int op =  bCode >> 26;
        unsigned int m = 31;
        unsigned int mask1 = m << 21;
        unsigned int mask2 = m << 16;
        unsigned int mask3 = m << 11;
        unsigned int mask4 = m << 6;
        unsigned int mask5 = pow(2, 16) - 1;
        unsigned int mask6 = pow(2, 26) - 1;

        if (op == 0){
            unsigned int func = bCode & 63;
            int* rs = registers + ((bCode & mask1) >> 21);
            int* rt = registers + ((bCode & mask2) >> 16);
            int* rd = registers + ((bCode & mask3) >> 11);
            int shamt = (bCode & mask4) >> 6;
            R0FuncMap[func](rs, rt, rd, shamt);
        }
        else if (op == 0x1c){
            unsigned int func = bCode & 63;
            int* rs = registers + ((bCode & mask1) >> 21);
            int* rt = registers + ((bCode & mask2) >> 16);
            int* rd = registers + ((bCode & mask3) >> 11);
            R0x1cFuncMap[func](rs, rt, rd);
        }
        else if (op == 1){
            int* rs = registers + ((bCode & mask1) >> 21);
            unsigned int func = (bCode & mask2) >> 16;
            int ac = bCode & mask5;
            I1FuncMap[func](rs, (int *) func, ac);
        }
        else{
            if (IFuncMap.find(op) != IFuncMap.end()){
                int* rs = registers + ((bCode & mask1) >> 21);
                int* rt = registers + ((bCode & mask2) >> 16);
                int ac = bCode & mask5;
                ac <<= 16;
                ac >>= 16;
                IFuncMap[op](rs, rt, ac);
            }
            else if (JFuncMap.find(op) != JFuncMap.end()){
                int target = bCode & mask6;
                JFuncMap[op](target);
            }
        }
    }
}