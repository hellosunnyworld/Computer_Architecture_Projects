//
// Created by 林沐晗 on 2021/3/19.
//

#ifndef PROJECTFSTR_SIMULATOR_H
#define PROJECTFSTR_SIMULATOR_H
#include <map>
#include <string>
typedef void RType0(int* rs, int* rt, int* rd, int shamt);
typedef void RType0x1c(int* rs, int* rt, int* rd);
typedef void IType(int* rs, int* rt, int ac);
typedef void JType(int target);

void simulate(unsigned int bCode, std::map<unsigned int, RType0*>& R0FuncMap,
              std::map<unsigned int, RType0x1c*>& R0x1cFuncMap,
              std::map<unsigned int, IType*>& I1FuncMap,
              std::map<unsigned int, IType*>& IFuncMap,
              std::map<unsigned int, JType*>& JFuncMap,
              std::ifstream& syscall_inputs, std::ofstream& output_file);

void R0FuncMapInit(std::map<unsigned int, RType0*>& R0FuncMap);
void R0x1cFuncMapInit(std::map<unsigned int, RType0x1c*>& R0x1cFuncMap);
void I1FuncMapInit(std::map<unsigned int, IType*>& I1FuncMap);
void IFuncMapInit(std::map<unsigned int, IType*>& IFuncMap);
void JFuncMapInit(std::map<unsigned int, JType*>& JFuncMap);
#endif //PROJECTFSTR_SIMULATOR_H
