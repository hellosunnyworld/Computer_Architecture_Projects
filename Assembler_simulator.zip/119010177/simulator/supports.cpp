//
// Created by 林沐晗 on 2021/3/19.
//

#include "supports.h"
#include "memory.h"
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sstream>

// int b = 0;
// FILE* input_mips = (FILE *) &b;
// FILE* syscall_inputs = (FILE *) &b;
// FILE* output_file = (FILE *) &b;

std::string IntToStr(int a){
    std::ostringstream stream;
    stream << a;
    return stream.str();
}
void addu (int* rs, int* rt, int* rd, int shamt){
    *rd = *rs + *rt;
}
void add (int* rs, int* rt, int* rd, int shamt){
    int sum = *rs + *rt;
    if (*rt > 0){
        if ((*rs > 0) && (sum < 0)){
            printf("Trap Exception: overflow of addi operation");
            exit(EXIT_FAILURE);
        }
    }else if (*rt < 0){
        if ((*rs < 0) && (sum > 0)){
            printf("Trap Exception: overflow of addi operation");
            exit(EXIT_FAILURE);
        }
    }
    *rd = sum;
}
void addiu (int* rs, int* rt, int imm){
    *rt = *rs + imm;
}
void addi (int* rs, int* rt, int imm){
    int sum = *rs + imm;
    if (imm > 0){
        if ((*rs > 0) && (sum < 0)){
            printf("Trap Exception: overflow of addi operation");
            exit(EXIT_FAILURE);
        }
    }else if (imm < 0){
        if ((*rs < 0) && (sum > 0)){
            printf("Trap Exception: overflow of addi operation");
            exit(EXIT_FAILURE);
        }
    }
    *rt = sum;
}

void and_ (int* rs, int* rt, int* rd, int shamt){
    *rd = *rs & *rt;
}
void andi (int* rs, int* rt, int imm){
    *rt = *rs & imm;
}

void clo (int* rs, int* rt, int* rd){
    int count = 0;
    std::string str = IntToStr(*rs);
    for (int i = 0; i < str.length(); i++){
        if (str[i] == '1')  count++;
        else    break;
    }
    *rd = count;
}
void clz(int* rs, int* rt, int* rd){
    int count = 0;
    std::string str = IntToStr(*rs);
    for (int i = 0; i < str.length(); i++){
        if (str[i] == '0')  count++;
        else    break;
    }
    *rd = count;
}

void div_(int* rs, int* rt, int* rd, int shamt) {
    int quot = *rs / *rt;
    int rem = *rs % *rt;
    *lo = quot;
    *hi = rem;
}

void divu (int* rs, int* rt, int* rd, int shamt){
    unsigned int a = *rs;
    unsigned int b = *rt;
    unsigned int quot = a / b;
    unsigned int rem = a % b;
    *lo = quot;
    *hi = rem;
}

void mult (int* rs, int* rt, int* rd, int shamt){
    long long m = (*rs) * (*rt);
    *hi = m >> 32;
    *lo = m;
}
void multu (int* rs, int* rt, int* rd, int shamt){
    long long m = unsigned (*rs) * unsigned (*rt);
    *hi = m >> 32;
    *lo = m;
}
void mul (int* rs, int* rt, int* rd){
    *rd = *rs * *rt;
}
void madd (int* rs, int* rt, int* rd){
    long long m = (*rs) * (*rt);
    long long n = ((*hi) << 32) + *lo;
    *hi = (m + n) >> 32;
    *lo = m + n;
}
void maddu (int* rs, int* rt, int* rd){    //??
    unsigned long long m = unsigned (*rs) * unsigned (*rt);
    long long n = ((*hi) << 32) + *lo;
    *hi = (m + n) >> 32;
    *lo = m + n;
}
void msub (int* rs, int* rt, int* rd){
    long long m = (*rs) * (*rt);
    long long n = ((*hi) << 32) + *lo;
    *hi = (n - m) >> 32;
    *lo = n - m;
}
void msubu (int* rs, int* rt, int* rd){    //??
    unsigned long long m = unsigned (*rs) * unsigned (*rt);
    long long n = ((*hi) << 32) + *lo;
    *hi = (n - m) >> 32;
    *lo = n - m;
}

void nor (int* rs, int* rt, int* rd, int shamt){
    *rd = !(*rs | *rt);
}
void or_ (int* rs, int* rt, int* rd, int shamt){
    *rd = (*rs) | (*rt);
}
void ori (int* rs, int* rt, int imm){
    *rt = (*rs) | imm;
}

void sll (int* rs, int* rt, int* rd, int shamt){
    *rd = *rt << shamt;
}
void sllv (int* rs, int* rt, int* rd, int shamt){
    *rd = *rt << *rs;
}
void sra (int* rs, int* rt, int* rd, int shamt){
    *rd = *rt >> shamt;
}
void srav (int* rs, int* rt, int* rd, int shamt){
    *rd = *rt >> *rs;
}
void srl (int* rs, int* rt, int* rd, int shamt){
    *rd = *rt >> shamt;
}
void srlv (int* rs, int* rt, int* rd, int shamt){
    *rd = *rt >> *rs;
}

void sub (int* rs, int* rt, int* rd, int shamt){
    *rd = *rs - *rt;
}
void subu (int* rs, int* rt, int* rd, int shamt){
    int dif = *rs - *rt;
    if (*rt > 0){
        if ((*rs > 0) && (dif < 0)){
            printf("Trap Exception: overflow of addi operation");
            exit(EXIT_FAILURE);
        }
    }else if (*rt < 0){
        if ((*rs < 0) && (dif > 0)){
            printf("Trap Exception: overflow of addi operation");
            exit(EXIT_FAILURE);
        }
    }
    *rd = dif;
}

void xor_ (int* rs, int* rt, int* rd, int shamt){
    *rd = (*rs) ^ (*rt);
}
void xori (int* rs, int* rt, int imm){
    *rt = (*rs) ^ imm;
}

void lui (int* rs, int* rt, int imm){
    imm <<= 16;
    *rt = imm;
}

void slt (int* rs, int* rt, int* rd, int shamt){
    *rd = (*rs < *rt) ? 1 : 0;
}
void sltu (int* rs, int* rt, int* rd, int shamt){
    *rd = (unsigned (*rs) < unsigned (*rt)) ? 1 : 0;
}
void slti (int* rs, int* rt, int imm){
    *rt = (*rs < imm) ? 1 : 0;
}
void sltiu (int* rs, int* rt, int imm){
    *rt = (unsigned (*rs) < unsigned (imm)) ? 1 : 0;
}

void beq (int* rs, int* rt, int offset){
    if (*rs == *rt) *pc += offset;
}
void bgez (int* rs, int* rt, int offset){
    if (*rs >= 0) *pc += offset;
}
void bgezal (int* rs, int* rt, int offset){
    if (*rs >= 0){
        *(registers + 31) = pseudo_mem(memory, *pc + 1);
        *pc += offset;
    }
}
void bgtz (int* rs, int* rt, int offset){
    if (*rs > 0) *pc += offset;
}
void blez (int* rs, int* rt, int offset){
    if (*rs <= 0) *pc += offset;
}
void bltzal (int* rs, int* rt, int offset){
    if (*rs < 0){
        *(registers + 31) = pseudo_mem(memory, *pc + 1);
        *pc += offset;
    }
}
void bltz(int *rs, int *rt, int offset) {
    if (*rs < 0) *pc += offset;
}
void bne (int* rs, int* rt, int offset){
    if (*rs != *rt) *pc += offset;
}

void j (int target){
    unsigned int crtPos = pseudo_mem(memory, *pc);
    unsigned int highDigits = (crtPos >> 28) << 28;
    //std::cout<<(highDigits + (target << 2))<<std::endl;
    *pc = real_mem(memory, highDigits + (target << 2)) - 1;
}
void jal (int target){
    *(registers + 31) = pseudo_mem(memory, *pc + 1);
    j(target);
}
void jalr (int* rs, int* rt, int* rd, int shamt){ //??????
    *rd = pseudo_mem(memory, *pc + 1);
    *pc = real_mem(memory, *rs) - 1;
}
void jr (int* rs, int* rt, int* rd, int shamt){
    *pc = real_mem(memory, *rs) - 1;
}

void teq (int* rs, int* rt, int* rd, int shamt){
    if (*rs == *rt){
        printf("Trap Exception: the values in the registers $rs and $rt are equal.");
        exit(EXIT_FAILURE);
    }
}
void teqi (int* rs, int* rt, int imm){
    if (*rs == imm){
        printf("Trap Exception: the value in the register $rs equals the immediate number.");
        exit(EXIT_FAILURE);
    }
}
void tne (int* rs, int* rt, int* rd, int shamt){
    if (*rs != *rt){
        printf("Trap Exception: the values in the registers $rs and $rt are not equal.");
        exit(EXIT_FAILURE);
    }
}
void tnei (int* rs, int* rt, int imm){
    if (*rs != imm){
        printf("Trap Exception: the value in the register $rs does not equal the immediate number.");
        exit(EXIT_FAILURE);
    }
}
void tge (int* rs, int* rt, int* rd, int shamt){
    if (*rs >= *rt){
        printf("Trap Exception: the value in the register $rs is not smaller than that in $rt.");
        exit(EXIT_FAILURE);
    }
}
void tgeu (int* rs, int* rt, int* rd, int shamt){
    if (unsigned (*rs) >= unsigned (*rt)){
        printf("Trap Exception: the unsigned number in the register $rs is not smaller than that in $rt.");
        exit(EXIT_FAILURE);
    }
}
void tgei (int* rs, int* rt, int imm){
    if (*rs >= imm){
        printf("Trap Exception: the value in the register $rs is not smaller than the immediate number.");
        exit(EXIT_FAILURE);
    }
}
void tgeiu (int* rs, int* rt, int imm){
    if (unsigned (*rs) >= unsigned (imm)){
        printf("Trap Exception: the unsigned number in the register $rs is not smaller than the unsigned immediate number.");
        exit(EXIT_FAILURE);
    }
}
void tlt (int* rs, int* rt, int* rd, int shamt){
    if (*rs < *rt){
        printf("Trap Exception: the value in the register $rs is smaller than that in $rt.");
        exit(EXIT_FAILURE);
    }
}
void tltu (int* rs, int* rt, int* rd, int shamt){
    if (unsigned (*rs) < unsigned (*rt)){
        printf("Trap Exception: the unsigned number in the register $rs is smaller than that in $rt.");
        exit(EXIT_FAILURE);
    }
}
void tlti (int* rs, int* rt, int imm){
    if (*rs < imm){
        printf("Trap Exception: the value in the register $rs is smaller than the immediate number.");
        exit(EXIT_FAILURE);
    }
}
void tltiu (int* rs, int* rt, int imm){
    if (unsigned (*rs) < unsigned (imm)){
        printf("Trap Exception: the unsigned number in the register $rs is smaller than the unsigned immediate number.");
        exit(EXIT_FAILURE);
    }
}

void lb (int* rs, int* rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;

    *rt = (*bw << 24) >> 24;
}
void lbu (int* rs, int* rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;
    *rt = *bw;
}
void lh (int* rs, int* rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint16_t * bw = (uint16_t *) realAd;
    bw += offset / 2;
    *rt = (*bw << 16) >> 16;
}
void lhu (int* rs, int* rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint16_t * bw = (uint16_t *) realAd;
    bw += offset / 2;
    *rt = *bw;
}// above 4:?????????
void lw (int* rs, int* rt, int offset){
    int* bw = real_mem(memory, *rs) + offset / 4;
    *rt = *bw;
}
void lwl (int* rs, int *rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;
    uint8_t * ad = (uint8_t *) rt;

    for (int i = 0; i < 4 - offset % 4; i++){
        *ad = *bw;
        ad++;
        bw++;
    }
}
void lwr (int* rs, int *rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;
    uint8_t * ad = (uint8_t *) rt;
    ad += 3;

    for (int i = 0; i < offset % 4 + 1; i++){
        *ad = *bw;
        ad--;
        bw--;
    }
}
// lwl lwr??????
void ll (int* rs, int* rt, int offset){
    int* bw = real_mem(memory, *rs) + offset / 4;
    *rt = *bw;
    *bw = 1;
}//???
void sc (int* rs, int* rt, int offset){
    int* bw = real_mem(memory, *rs) + offset / 4;
    *bw = *rt;
    *rt = 1;
}
void sb (int* rs, int* rt, int offset){
//    int* bw = rs + (offset + 1) / 4;
//    int lsp = 8 * (offset % 4);
//
//    unsigned int content = *rt << 24;
//    content >>= lsp; // 000..0content000...
//
//    int mask = pow(2,8) - 1;
//    mask <<= 24 - lsp; //00..011..100..0
//    mask = ~mask; //11..100..011..1
//    *bw &= mask; // Clears the goal area
//    *bw |= content;
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;
    *bw = *rt;
}
void sh (int* rs, int* rt, int offset){
//    int* bw = rs + (offset + 1) / 4;
//    int lsp = 8 * (offset % 4);
//
//    unsigned int content = *rt << 16;
//    content >>= lsp; // 000..0content000...
//
//    int mask = pow(2,16) - 1;
//    mask <<= 16 - lsp; //00..011..100..0
//    mask = ~mask; //11..100..011..1
//    *bw &= mask; // Clears the goal area
//    *bw |= content;
    int *realAd = real_mem(memory, *rs);
    uint16_t * bw = (uint16_t *) realAd;
    bw += offset / 2;
    *bw = *rt;
}
void sw (int* rs, int* rt, int offset){
    int* bw = real_mem(memory, *rs) + offset / 4;
    *bw = *rt;
}
void swl (int* rs, int *rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;
    uint8_t * ad = (uint8_t *) rt;

    for (int i = 0; i < 4 - offset % 4; i++){
        *bw = *ad;
        ad++;
        bw++;
    }
}
void swr (int* rs, int *rt, int offset){
    int *realAd = real_mem(memory, *rs);
    uint8_t * bw = (uint8_t *) realAd;
    bw += offset;
    uint8_t * ad = (uint8_t *) rt;
    ad += 3;

    for (int i = 0; i < offset % 4 + 1; i++){
        *bw = *ad;
        ad--;
        bw--;
    }
}

// swl swr??????

void mfhi (int* rs, int* rt, int* rd, int shamt){
    *rd = *hi;
}
void mflo (int* rs, int* rt, int* rd, int shamt){
    *rd = *lo;
}
void mthi (int* rs, int* rt, int* rd, int shamt){
    *hi = *rs;
}
void mtlo (int* rs, int* rt, int* rd, int shamt){
    *lo = *rs;
}


void print_int(std::ofstream& output_file){
    //fprintf(output_file, "%d", *(registers + 4));
    output_file << *(registers + 4);
    output_file.flush();
}
void print_string(std::ofstream& output_file){
    int* realAd = real_mem(memory, *(registers + 4));
    //std::cout<<*(registers + 4)<<std::endl;
    char* ch = (char *) realAd;
    while (*ch != '\0'){
        //printf("%c", *ch);
        output_file << *ch;
        output_file.flush();
        ch += 1;
    }
}
void read_int(std::ifstream& syscall_inputs){
    int x;
    syscall_inputs >> x;
    *(registers + 2) = x;
}
void read_string(std::ifstream& syscall_inputs){
    int* realAd = real_mem(memory, *(registers + 4));
    char* t = (char *) realAd;
    //char str[*(registers + 5) + 1];
    //fgets(str, *(registers + 5), syscall_inputs);
    for (int i = 0; i < *(registers + 5); i++){
        *t = syscall_inputs.get();
        //*t = str[i];
        t += 1;
    }
    *t = '\0';
}
void sbrk(){
    *(registers + 2) = pseudo_mem(memory, heapTop);
    heapTop += *(registers + 4) / 4;
    heapTop = (*(registers + 4) % 4 > 0) ? heapTop : (heapTop + 1);
}
void exit_(){
    exit(EXIT_SUCCESS);
}
void print_char(std::ofstream& output_file){
    char c = *(registers + 4);
    //fprintf(output_file, "%c", c);
    output_file << c;
    output_file.flush();
}
void read_char(std::ifstream& syscall_inputs){
    //char* c = new char;
    //fgets(c, 1, syscall_inputs);
    *(registers + 2) = syscall_inputs.get();
    //*(registers + 2) = *c;
    //delete c;
}
void open_(){
    int* realAd = real_mem(memory, *(registers + 4));
    char* ch = (char *) realAd;
    std::string fileName = "";
    while (*ch != '\0'){
        fileName += *ch;
        ch += 1;
    }
    *(registers + 2) = open(fileName.c_str(), *(registers + 5), *(registers + 6));
}
void read_(){
    int* realAd = real_mem(memory, *(registers + 5));
    char* ch = (char *) realAd;
    *(registers + 2) = read(*(registers + 4), ch, *(registers + 6));
}
void write_(){
    int* realAd = real_mem(memory, *(registers + 5));
    char* ch = (char *) realAd;
    *(registers + 2) = write(*(registers + 4), ch, *(registers + 6));
}
void close_(){
    close(*(registers + 4));
}
void exit2_(){
    exit(*(registers + 4));
}

void syscall(std:: ifstream& syscall_inputs, std::ofstream& output_file){
    switch (*(registers + 2)) {
        case 1:
            print_int(output_file);
            break;
        case 4:
            print_string(output_file);
            break;
        case 5:
            read_int(syscall_inputs);
            break;
        case 8:
            read_string(syscall_inputs);
            break;
        case 9:
            sbrk();
            break;
        case 10:
            exit_();
            break;
        case 11:
            print_char(output_file);
            break;
        case 12:
            read_char(syscall_inputs);
            break;
        case 13:
            open_();
            break;
        case 14:
            read_();
            break;
        case 15:
            write_();
            break;
        case 16:
            close_();
            break;
        case 17:
            exit2_();
            break;
    }
}