//
// Created by 林沐晗 on 2021/3/19.
//

#ifndef PROJECTFSTR_SUPPORTS_H
#define PROJECTFSTR_SUPPORTS_H
#include <cstdio>
#include <string>
#include <fstream>

// extern FILE* input_mips;
// extern FILE* syscall_inputs;
// extern FILE* output_file;

std::string IntToStr(int a);

void add (int* rs, int* rt, int* rd, int shamt);
void addu (int* rs, int* rt, int* rd, int shamt);
void addi (int* rs, int* rt, int imm);
void addiu (int* rs, int* rt, int imm);

void clo (int* rs, int* rt, int* rd);
void clz (int* rs, int* rt, int* rd);

void and_ (int* rs, int* rt, int* rd, int shamt);
void andi (int* rs, int* rt, int imm);

void div_ (int* rs, int* rt, int* rd, int shamt);
void divu (int* rs, int* rt, int* rd, int shamt);

void mult (int* rs, int* rt, int* rd, int shamt);
void multu (int* rs, int* rt, int* rd, int shamt);
void mul (int* rs, int* rt, int* rd);
void madd (int* rs, int* rt, int* rd);
void maddu (int* rs, int* rt, int* rd);
void msub (int* rs, int* rt, int* rd);
void msubu (int* rs, int* rt, int* rd);

void nor (int* rs, int* rt, int* rd, int shamt);
void or_ (int* rs, int* rt, int* rd, int shamt);
void ori (int* rs, int* rt, int imm);

void sll (int* rs, int* rt, int* rd, int shamt);
void sllv (int* rs, int* rt, int* rd, int shamt);
void sra (int* rs, int* rt, int* rd, int shamt);
void srav (int* rs, int* rt, int* rd, int shamt);
void srl (int* rs, int* rt, int* rd, int shamt);
void srlv (int* rs, int* rt, int* rd, int shamt);

void sub (int* rs, int* rt, int* rd, int shamt);
void subu (int* rs, int* rt, int* rd, int shamt);

void xor_ (int* rs, int* rt, int* rd, int shamt);
void xori (int* rs, int* rt, int imm);

void lui (int* rs, int* rt, int imm);

void slt (int* rs, int* rt, int* rd, int shamt);
void sltu (int* rs, int* rt, int* rd, int shamt);
void slti (int* rs, int* rt, int imm);
void sltiu (int* rs, int* rt, int imm);

void beq (int* rs, int* rt, int offset);
void bgez (int* rs, int* rt, int offset);
void bgezal (int* rs, int* rt, int offset);
void bgtz (int* rs, int* rt, int offset);
void blez (int* rs, int* rt, int offset);
void bltzal (int* rs, int* rt, int offset);
void bltz(int *rs, int *rt, int offset);
void bne (int* rs, int* rt, int offset);

void j (int target);
void jal (int target);
void jalr (int* rs, int* rt, int* rd, int shamt);
void jr (int* rs, int* rt, int* rd, int shamt);

void teq (int* rs, int* rt, int* rd, int shamt);
void teqi (int* rs, int* rt, int imm);
void tne (int* rs, int* rt, int* rd, int shamt);
void tnei (int* rs, int* rt, int imm);
void tge (int* rs, int* rt, int* rd, int shamt);
void tgeu (int* rs, int* rt, int* rd, int shamt);
void tgei (int* rs, int* rt, int imm);
void tgeiu (int* rs, int* rt, int imm);
void tlt (int* rs, int* rt, int* rd, int shamt);
void tltu (int* rs, int* rt, int* rd, int shamt);
void tlti (int* rs, int* rt, int imm);
void tltiu (int* rs, int* rt, int imm);

void lb (int* rs, int* rt, int offset);
void lbu (int* rs, int* rt, int offset);
void lh (int* rs, int* rt, int offset);
void lhu (int* rs, int* rt, int offset);
void lw (int* rs, int* rt, int offset);
void lwl (int* rs, int *rt, int offset);
void lwr (int* rs, int *rt, int offset);
void ll (int* rs, int* rt, int offset);
void sc (int* rs, int* rt, int offset);
void sb (int* rs, int* rt, int offset);
void sh (int* rs, int* rt, int offset);
void sw (int* rs, int* rt, int offset);
void swl (int* rs, int *rt, int offset);
void swr (int* rs, int *rt, int offset);

void mfhi (int* rs, int* rt, int* rd, int shamt);
void mflo (int* rs, int* rt, int* rd, int shamt);
void mthi (int* rs, int* rt, int* rd, int shamt);
void mtlo (int* rs, int* rt, int* rd, int shamt);

void print_int(std::ofstream& output_file);
void print_string(std::ofstream& output_file);
void read_int(std::ifstream& syscall_inputs);
void read_string(std::ifstream& syscall_inputs);
void sbrk();
void exit_();
void print_char(std::ofstream& output_file);
void read_char(std::ifstream& syscall_inputs);
void open_();
void read_();
void write_();
void close_();
void exit2_();
void syscall(std::ifstream& syscall_inputs, std::ofstream& output_file);

#endif //PROJECTFSTR_SUPPORTS_H
